"""Small public adapter API; causal hooks live in mechanism modules."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from PIL import Image


@dataclass(frozen=True)
class AdapterCapabilities:
    supports_activation_intervention: bool = False
    supports_layer_mapping: bool = False
    supports_kv_hooks: bool = False


class VLMAdapter(ABC):
    model_family = "unknown"
    capabilities = AdapterCapabilities()

    def __init__(self, model_path: str | Path, **runtime: Any):
        self.model_path = Path(model_path).expanduser().resolve()
        self.runtime = dict(runtime)

    def prepare_image(self, image_path: str | Path) -> Image.Image:
        return Image.open(image_path).convert("RGB")

    @abstractmethod
    def prepare_prompt(self, prompt: str, image_path: str | Path | None = None) -> Any:
        raise NotImplementedError

    @abstractmethod
    def generate(self, prepared: Any) -> str:
        raise NotImplementedError

    def normalize_output(self, output: str) -> str:
        return str(output).strip()

    def get_model_metadata(self) -> dict[str, Any]:
        return {
            "model_family": self.model_family,
            "model_path": str(self.model_path),
            "runtime": self.runtime,
            "capabilities": asdict(self.capabilities),
        }

