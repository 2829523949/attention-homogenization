from __future__ import annotations

from ._hf_chat import HFImageTextAdapter
from .base_adapter import AdapterCapabilities


class Qwen35Adapter(HFImageTextAdapter):
    model_family = "qwen3.5"
    chat_template_kwargs = {"enable_thinking": False}
    capabilities = AdapterCapabilities(
        supports_activation_intervention=True,
        supports_layer_mapping=True,
        supports_kv_hooks=True,
    )

