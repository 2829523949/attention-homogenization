from __future__ import annotations

from ._hf_chat import HFImageTextAdapter
from .base_adapter import AdapterCapabilities


class LlavaNextAdapter(HFImageTextAdapter):
    model_family = "llava-next"
    capabilities = AdapterCapabilities(
        supports_activation_intervention=True,
        supports_layer_mapping=True,
        supports_kv_hooks=False,
    )

