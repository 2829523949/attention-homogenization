from .base_adapter import AdapterCapabilities, VLMAdapter
from .internvl import InternVL35Adapter
from .llava_next import LlavaNextAdapter
from .qwen35 import Qwen35Adapter
from .qwen3vl import Qwen3VLAdapter

ADAPTERS = {
    "qwen35": Qwen35Adapter,
    "qwen3vl": Qwen3VLAdapter,
    "internvl35": InternVL35Adapter,
    "llava_next": LlavaNextAdapter,
}

__all__ = ["ADAPTERS", "AdapterCapabilities", "VLMAdapter"]

