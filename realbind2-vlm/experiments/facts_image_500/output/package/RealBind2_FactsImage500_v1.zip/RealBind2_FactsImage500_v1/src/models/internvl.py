"""InternVL adapter kept separate because its remote-code chat API differs."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base_adapter import VLMAdapter


class InternVL35Adapter(VLMAdapter):
    model_family = "internvl3.5"

    def _load(self) -> None:
        if hasattr(self, "model"):
            return
        import torch
        from transformers import AutoModel, AutoTokenizer

        dtype = getattr(torch, str(self.runtime.get("dtype", "bfloat16")))
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, trust_remote_code=True, use_fast=False)
        self.model = AutoModel.from_pretrained(
            self.model_path,
            torch_dtype=dtype,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
        ).eval().to(self.runtime.get("device", "cuda"))

    def prepare_prompt(self, prompt: str, image_path: str | Path | None = None) -> dict[str, Any]:
        self._load()
        if image_path is None:
            return {"question": prompt, "pixel_values": None}
        try:
            from internvl.train.dataset import build_transform, dynamic_preprocess
        except ImportError as exc:
            raise RuntimeError("InternVL preprocessing package is not installed; see envs/main_vlm") from exc
        image = self.prepare_image(image_path)
        tiles = dynamic_preprocess(image, image_size=448, use_thumbnail=True, max_num=12)
        transform = build_transform(is_train=False, input_size=448)
        import torch
        pixels = torch.stack([transform(tile) for tile in tiles]).to(self.runtime.get("device", "cuda"))
        return {"question": "<image>\n" + prompt, "pixel_values": pixels}

    def generate(self, prepared: dict[str, Any]) -> str:
        return self.model.chat(
            self.tokenizer,
            prepared["pixel_values"],
            prepared["question"],
            {"do_sample": False, "max_new_tokens": int(self.runtime.get("max_new_tokens", 16))},
        )

