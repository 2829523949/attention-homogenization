"""Lazy Hugging Face image/text adapter shared by compatible checkpoints."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from .base_adapter import VLMAdapter


class HFImageTextAdapter(VLMAdapter):
    chat_template_kwargs: dict[str, Any] = {}

    def _load(self) -> None:
        if hasattr(self, "model"):
            return
        import torch
        from transformers import AutoModelForImageTextToText, AutoProcessor

        dtype_name = str(self.runtime.get("dtype", "bfloat16"))
        dtype = getattr(torch, dtype_name)
        self.processor = AutoProcessor.from_pretrained(self.model_path, trust_remote_code=True)
        self.model = AutoModelForImageTextToText.from_pretrained(
            self.model_path,
            torch_dtype=dtype,
            device_map=self.runtime.get("device_map", None),
            trust_remote_code=True,
        )
        device = self.runtime.get("device", "cuda")
        if self.runtime.get("device_map") is None:
            self.model.to(device)
        self.model.eval()

    def prepare_prompt(self, prompt: str, image_path: str | Path | None = None) -> dict[str, Any]:
        self._load()
        content: list[dict[str, Any]] = []
        images = None
        if image_path is not None:
            images = [self.prepare_image(image_path)]
            content.append({"type": "image"})
        content.append({"type": "text", "text": prompt})
        messages = [{"role": "user", "content": content}]
        rendered = self.processor.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            **self.chat_template_kwargs,
        )
        encoded = self.processor(text=[rendered], images=images, return_tensors="pt")
        device = next(self.model.parameters()).device
        return {key: value.to(device) for key, value in encoded.items()}

    def generate(self, prepared: dict[str, Any]) -> str:
        import torch

        with torch.inference_mode():
            generated = self.model.generate(
                **prepared,
                do_sample=False,
                use_cache=bool(self.runtime.get("use_cache", False)),
                max_new_tokens=int(self.runtime.get("max_new_tokens", 16)),
            )
        prompt_length = int(prepared["input_ids"].shape[1])
        return self.processor.batch_decode(generated[:, prompt_length:], skip_special_tokens=True)[0]

